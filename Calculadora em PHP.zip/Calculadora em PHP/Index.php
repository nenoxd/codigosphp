<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calculadora PHP</title>
</head>
<body>
    <h2>Calculadora PHP</h2>

    <form action="" method="post">
        <label for="num1">Número 1:</label>
        <input type="number" name="num1" required>
        <br>
        <label for="num2">Número 2:</label>
        <input type="number" name="num2" required>
        <br>
        <label for="operacao">Operação:</label>
        <select name="operacao">
            <option value="soma">Soma</option>
            <option value="subtracao">Subtração</option>
            <option value="multiplicacao">Multiplicação</option>
            <option value="divisao">Divisão</option>
        </select>
        <br>
        <input type="submit" value="Calcular">
    </form>

    <?php
    // Verifica se os números foram fornecidos
    if (isset($_POST['num1']) && isset($_POST['num2'])) {
        $num1 = $_POST['num1'];
        $num2 = $_POST['num2'];

        // Verifica a operação selecionada
        if (isset($_POST['operacao'])) {
            $operacao = $_POST['operacao'];

            // Realiza a operação correspondente
            switch ($operacao) {
                case 'soma':
                    $resultado = $num1 + $num2;
                    break;
                case 'subtracao':
                    $resultado = $num1 - $num2;
                    break;
                case 'multiplicacao':
                    $resultado = $num1 * $num2;
                    break;
                case 'divisao':
                 
                    if ($num2 != 0) {
                        $resultado = $num1 / $num2;
                    } else {
                        echo '<p style="color: red;">Erro: Divisão por zero.</p>';
                    }
                    break;
                default:
                    echo '<p style="color: red;">Erro: Operação inválida.</p>';
                    break;
            }

           
            if (isset($resultado)) {
                echo '<p>O resultado da operação é: ' . $resultado . '</p>';
            }
        }
    } else {
    
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            echo '<p style="color: red;">Erro: Números não fornecidos.</p>';
        }
    }
    ?>
</body>
</html>
